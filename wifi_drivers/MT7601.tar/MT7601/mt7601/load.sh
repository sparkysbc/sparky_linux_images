insmod mt7601Usta.ko 
depmod -a
#ifconfig ra0 up
