rmmod mt7601Usta.ko 

#ifconfig ra0 down
