#!/bin/sh
ver=$(uname -r) 
echo "$ver"
sudo mkdir /etc/Wireless/
sudo rm -rf /etc/Wireless/RT2870STA/
sudo mkdir /etc/Wireless/RT2870STA/
sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/RT2870STA.dat
sudo chmod 777 -R /etc/Wireless/RT2870STA
sudo cp -pr mt7610/ /lib/modules/$ver/kernel/drivers/net/wireless/
cd /lib/modules/$ver/kernel/drivers/net/wireless/mt7610/
sudo sh load.sh
exit 0

