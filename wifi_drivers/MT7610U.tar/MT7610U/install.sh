#!/bin/sh
ver=$(uname -r)
ver_match=0
#echo "$ver"
if [ "$ver" = "3.10.38" ]; then
  echo "kernel version is '$ver'"
sudo rm -rf /lib/modules/$ver/kernel/drivers/net/wireless/mt7610
sudo cp -pr mt7610_38/ /lib/modules/$ver/kernel/drivers/net/wireless/mt7610
ver_match=1
fi
if [ "$ver_match" = "1" ]; then
  echo "kernel matching"
sudo mkdir /etc/Wireless/
sudo mkdir /etc/Wireless/RT2870STA/
sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/RT2870STA.dat
sudo chmod 777 -R /etc/Wireless/RT2870STA
cd /lib/modules/$ver/kernel/drivers/net/wireless/mt7610/
sudo sh load.sh
else
 echo "kernel version not matching"
fi
exit 0

