insmod mt7650u_sta_util.ko 
insmod mt7650u_sta.ko    
insmod mt7650u_sta_net.ko
depmod -a
#ifconfig ra0 up
