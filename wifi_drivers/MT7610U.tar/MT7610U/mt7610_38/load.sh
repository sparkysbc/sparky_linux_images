sudo insmod mt7650u_sta.ko    
sudo depmod -a
#ifconfig wlan0 up
