sudo ifconfig wlan0 down
sudo rmmod mt7650u_sta.ko
